module.exports = function() {
	this.Hello = function(name) { return "Hello to " + name; }
}

